
#include <iostream>
#include "biblioteca/funciones/files.hpp"
#include "biblioteca/funciones/strings.hpp"
#include "biblioteca/funciones/tokens.hpp"
#include "biblioteca/tads/parte1/Coll.hpp"
#include "biblioteca/tads/parte2/Array.hpp"
#include "biblioteca/tads/parte2/List.hpp"
#include "biblioteca/tads/parte2/Map.hpp"
#include "biblioteca/tads/parte2/Queue.hpp"
#include "biblioteca/tads/parte2/Stack.hpp"
#include "principal.hpp"

using std::cin;
using std::cout;
using std::endl;
using std::getline;
using std::string;

int main()
{
    List<string> lst = list<string>();
    listAdd<string>(lst,"Pedro");
    listAdd<string>(lst,"Pablo");
    listAdd<string>(lst,"Juan");
    string* s = listFind<string,string>(lst,"Pablo",cmpString);
    cout << *s << endl;

    Array<string> a = array<string>();
    arrayAdd<string>(a,"Pablo");
    arrayAdd<string>(a,"Pedro"); 
    arrayAdd<string>(a,"Juan");
    int i = arrayFind<string,string>(a,"Pablo",cmpString);
    cout << i << endl;







    return 0;
}

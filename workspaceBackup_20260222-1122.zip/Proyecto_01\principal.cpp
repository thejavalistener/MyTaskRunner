#include <iostream>
#include <string>
using std::string;
using std::cout;
using std::cin;
using std::endl;
using std::getline;


int main()
{
    cout << "Hola Mundo !" << endl;
    return 0;    
}

